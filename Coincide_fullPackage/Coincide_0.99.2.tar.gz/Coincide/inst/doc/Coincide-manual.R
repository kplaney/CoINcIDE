### R code from vignette source 'Coincide-manual.Rnw'

###################################################
### code chunk number 1: style-Sweave
###################################################
BiocStyle::latex()


###################################################
### code chunk number 2: Coincide-manual.Rnw:26-28
###################################################
library("Coincide")
#will include examples soon.


